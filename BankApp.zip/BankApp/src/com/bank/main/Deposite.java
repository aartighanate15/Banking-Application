package com.bank.main;

import java.util.Scanner;

import com.bank.dao.Bankdao;
import com.bank.dao.BankdaoImp;
import com.bank.dto.Customer;
import com.bank.dto.Transaction;

public class Deposite {
	
	public static void GetDeposite(Customer c) {
		Scanner in = new Scanner(System.in);
		Bankdao bdao = new BankdaoImp();
		System.out.println("Enter the Amount");
		double amount = in.nextDouble();
		System.out.println("Enter pin");
		int pin = in.nextInt();
		if (c.getPin() == pin) {
			c.setBal(amount + c.getBal());
			System.out.println("Deposite Successful");
			boolean result = bdao.updateCustomer(c);
			
		}else {
			System.out.println("Invalide Pin");
		}
		
	}
}
