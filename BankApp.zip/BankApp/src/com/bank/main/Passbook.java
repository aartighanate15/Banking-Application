package com.bank.main;

import com.bank.dto.Customer;

public class Passbook {
	public static void Getpassbook(Customer c) {
		
	}
}
